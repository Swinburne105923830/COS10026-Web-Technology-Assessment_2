[Preview](https://htmlpreview.github.io/?https://github.com/Swinburne105923830/COS10026-Web-Technology-Assessment/blob/main/index.html)
# COS10026-Web-Technology-Assessment Part 2
## Purpose & Scenario
Build a static recruitment website using validated HTML5 & CSS3 (no JavaScript/Bootstrap). The site must follow accessibility standards, proper structure, and be deployed via GitHub Pages.

**Scenario:**
An IT company wants a site to advertise jobs with position descriptions and an application form.

**Industries and topics:**
A university department seeking support in digital learning and research
