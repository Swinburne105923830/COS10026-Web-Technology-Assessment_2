<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Apply Page for Hogwarts School of WitchCraft & Wizardry">
        <meta name="keywords" content="HTML, Application, Form, Hogwarts">
        <meta name="author" content="Jacob Grant">
        <title>Apply Page</title>
    </head>
    <body class="page_apply">
        
        <?php include "header.inc" ?>
        
        <main>
        <h1 class="apply_heading">Application Page for Hogwarts School of Witchcraft and Wizardry</h1>
            <form action="process_eoi.php" method="post" novalidate="novalidate">
                <fieldset>
                    <legend><strong>Applicant Information</strong></legend>
                    <fieldset>
                        <legend><strong>Personal Details</strong></legend>
                        <label for="firstname">First Name:</label>
                        <input type="text" id="firstname" name="firstname">
                        <br>
                        <label for="lastname">Last Name:</label>
                        <input type="text" id="lastname" name="lastname">
                        <br>
                        <label for="dob">Date of Birth:</label>
                        <input type="date" id="dob" name="dob">
                        <br>
                        
                        <br>
                        <fieldset>
                            <legend>Gender</legend>
                            <input type="radio" id="male" name="gender" value="male" checked="checked">
                            <label for="male">Male</label>
                            <input type="radio" id="female" name="gender" value="female">
                            <label for="female">Female</label>
                            <input type="radio" id="other" name="gender" value="other">
                            <label for="other">Other</label>
                        </fieldset>
                        <br>

                        <label for="address">Street Address:</label>
                        <input type="text" id="address" name="address">
                        <label for="suburb">Suburb/Town:</label>
                        <input type="text" id="suburb" name="suburb">
                        <br>

                        <label for="state">State:</label>
                        <select id="state" name="state">
                            <option value="">Please Select State</option>
                            <option value="vic">VIC</option>
                            <option value="nsw">NSW</option>
                            <option value="qld">QLD</option>
                            <option value="nt">NT</option>
                            <option value="wa">WA</option>
                            <option value="sa">SA</option>
                            <option value="tas">TAS</option>
                            <option value="act">ACT</option>
                        </select>
                        <br>
                        <label for="postcode">Postcode:</label>
                        <input type="text" id="postcode" name="postcode">
                        <br>

                        <br>
                        <label><strong>Contact Information:</strong></label>
                        <br>
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email">
                        <br>
                        <label for="phone">Phone:</label>
                        <input type="text" id="phone" name="phone">
                        <br>
                    </fieldset>
                    <fieldset>
                        <legend><strong>Job Details</strong></legend>
                        <p><em>Please read full job description on <strong><a href="jobs.html">Jobs Page</a></strong> before applying to role</em></p>
                        <br>
                        <label for="job_reference">Job Reference Number:</label>
                        <input type="text" id="job_reference" name="job_reference" pattern="[a-zA-Z\d]{5}" required>
                        <br>

                    <br>
                    
                    <fieldset>
                        <!-- Removed ID from each checkbox to properly insert them into an array in process_eoi -->
                        <legend><strong>Skills List (Tick all that apply):</strong></legend>
                        <label for="teaching">Teaching Qualification</label>
                        <input type="checkbox" name="skills[]" value="teaching"> 
                        <br>
                        <label for="systems">Management Systems Knowledge</label>
                        <input type="checkbox" name="skills[]" value="systems">
                        <br>
                        <label for="technology">Technology Expertise</label>
                        <input type="checkbox" name="skills[]" value="systems"> 
                        <br>
                        <label for="communication">Communication Skills</label>
                        <input type="checkbox" name="skills[]" value="communication">
                        <br>
                        <label for="pl_sql">PL/SQL Proficiency</label>
                        <input type="checkbox" name="skills[]" value="pl_sql"> 
                        <br>
                        <label for="html">HTML Proficency</label>
                        <input type="checkbox" name="skills[]" value="html"> 
                        <br>
                        <label for="css">CSS Proficency</label>
                        <input type="checkbox" name="skills[]" value="css"> 
                        <br>
                        <label for="aws">AWS Database Experience</label>
                        <input type="checkbox" name="skills[]" value="aws"> 
                        <br>
                        <label for="experience">5+ Years Industry Experience</label>
                        <input type="checkbox" name="skills[]" value="experience"> 
                        <br>
                        <label for="other_skills_checkbox">Other Skills:</label>
                        <input type="checkbox" name="skills[]" value="other_skills"> 
                        <br>
                        <textarea id="other_skills_text" name="other_skills_text" rows="4" cols="40" placeholder="Enter other relevant skills here..."></textarea> 
                    </fieldset> 


                </fieldset>
                
                <input type="submit" value="Register">
                <input type="reset" value="Clear Form">
            </fieldset>
        </form>

        <?php include "footer.inc" ?>
        
    </body>
</html>